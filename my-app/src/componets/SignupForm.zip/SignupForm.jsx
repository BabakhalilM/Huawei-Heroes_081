
import React, { useEffect, useState } from 'react';
import './signup.css';
import { Link } from 'react-router-dom';
import axios from 'axios';

const SignupForm = () => {
  const [formData, setFormData] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    fruit: ''
  });


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };
  useEffect(()=>{
    const fetchData=async ()=>{
      try{
        const responce= await axios.get("https://huawei-heroes-081-986o.onrender.com/user");
        console.log(responce.data);
      }catch (err){
        console.log("Error accur:",err);

      }
    }
    // fetchData;
  },[]);

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add form validation logic here (e.g., check password confirmation)
    console.log('Form submitted:', formData);
    // Example: Check if password and confirmPassword match
    if (formData.password !== formData.confirmPassword) {
      alert("Passwords do not match!");
      return;
    }


    // Example: Send formData to server for registration
    // axios.post('/api/signup', formData)
    //   .then(response => {
    //     console.log('Signup successful!', response.data);
    //     // Navigate to login page after successful signup
    //     // You can use useHistory or useNavigate for navigation
    //   })
    //   .catch(error => {
    //     console.error('Error signing up:', error);
    //     // Handle error (e.g., display error message)
    //   });
  };

  return (
    <div className="signup-container">
      <form className="signup-form" onSubmit={handleSubmit}>
        <h2>Sign Up</h2>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleChange}
            required
          />
        </div>
        <div className='questions'>
          <h6>when you forgot password you can login by answering this Questions</h6>
          <label htmlFor="q1">Q1: Enter your Favorite Fruit along with your Friend Name : </label>
          <input type="text" id='q1' name='fruit' onChange={handleChange} required value={formData.fruit}/>
        </div>
        <br/>
        <button type="submit">Sign Up</button>
        <p>Already have an account? <Link to="/LoginForm">Login</Link></p>
      </form>
    </div>
  );
};

export default SignupForm;
